(function (app) {
  'use strict';

  app.registerModule('contactform');
}(ApplicationConfiguration));
