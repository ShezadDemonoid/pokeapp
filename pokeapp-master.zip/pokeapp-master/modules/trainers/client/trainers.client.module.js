(function (app) {
  'use strict';

  app.registerModule('trainers');
}(ApplicationConfiguration));
