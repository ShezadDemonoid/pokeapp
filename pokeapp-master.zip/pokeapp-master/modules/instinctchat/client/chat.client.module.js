(function (app) {
  'use strict';

  app.registerModule('chat');
}(ApplicationConfiguration));
