(function (app) {
  'use strict';

  app.registerModule('poketeam');
}(ApplicationConfiguration));
