(function (app) {
  'use strict';

  app.registerModule('search');
}(ApplicationConfiguration));
