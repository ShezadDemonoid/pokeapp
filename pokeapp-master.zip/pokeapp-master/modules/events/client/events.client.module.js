(function (app) {
  'use strict';

  app.registerModule('events');
}(ApplicationConfiguration));
