(function (app) {
  'use strict';

  app.registerModule('valorchat');
}(ApplicationConfiguration));
