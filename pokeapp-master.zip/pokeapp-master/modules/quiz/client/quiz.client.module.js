(function (app) {
  'use strict';

  app.registerModule('quiz');
}(ApplicationConfiguration));
