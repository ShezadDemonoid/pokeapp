(function (app) {
  'use strict';

  app.registerModule('mystichat');
}(ApplicationConfiguration));
