(function() {
  'use strict';

  // Chat module config
  angular
    .module('mystichat')
    .run(menuConfig);

  menuConfig.$inject = ['Menus'];

  function menuConfig(Menus) {
    // Config logic
    // ...
    
      
  }
})();
